<?php
/**
 * External product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/external.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_add_to_cart_button' ); ?>

<div class="cart">
	<?php thegem_button(array(
		'text' => $button_text,
		'href' => esc_url($product_url),
		'attributes' => array('rel' => 'nofollow', 'class' => 'single_add_to_cart_button button alt'),
	), 1); ?>
	<?php do_action('thegem_woocommerce_after_add_to_cart_button'); ?>
</div>

<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
