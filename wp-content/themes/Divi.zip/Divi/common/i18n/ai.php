<?php
/**
 * Internationalization.
 *
 * @package Divi
 */

return [
	'Search'          => esc_html__( 'Search', 'et_builder' ),
	'Translate'       => esc_html__( 'Translate', 'et_builder' ),
	'Quick Actions'   => esc_html__( 'Quick Actions', 'et_builder' ),
];
